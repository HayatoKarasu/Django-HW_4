from django.apps import AppConfig


class ArbitraryNameConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'arbitrary_name'
