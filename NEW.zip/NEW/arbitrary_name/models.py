from django.db import models


class Human(models.Model):
    Last_name = models.CharField(max_length=30)
    First_name = models.CharField(max_length=30)
    Last_name2 = models.CharField(max_length=30)
    Residence = models.CharField(max_length=100)
    Birthdate = models.DateField()
    Characteristic = models.TextField(blank=True)
    Photo = models.ImageField(upload_to='photo/%Y/%m/%d')
    Update = models.DateTimeField(auto_now=True)
    Registration = models.BooleanField(default=True)
